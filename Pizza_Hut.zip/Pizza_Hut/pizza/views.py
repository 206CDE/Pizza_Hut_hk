from django.shortcuts import render,redirect
from django.db.models import Q
from .models import *
from .forms import *
import os

# Create your views here.
def index(request):
    pizza_list = []
    print(os.getcwd())
    for item in os.listdir('static/Pizza'):
##        print(item)
        pizza_list.append(item)
    
    context = {'pizza_list':pizza_list}
    return render(request,'index.html',context)

def pizza_list(request):
##    meals = Food.objects.all()
    meals = Food.objects.filter(menu__type_of_food__icontains='Pizza')
##    print(meals)
    context = {'meals':meals}
    return render(request,'pizza_list.html',context)

def pasta_list(request):
##    meals = Food.objects.all()
    meals = Food.objects.filter(menu__type_of_food__icontains='Pasta')
##    print(meals)
    context = {'meals':meals}
    return render(request,'pasta_list.html',context)

def shop(request):
    foods = Food.objects.all()
    meals = SetMeal.objects.all()
    context = {'foods':foods,'meals':meals}
    return render(request,'shop.html',context)

def add_to_cart(request):
    food_name = request.POST.getlist('food_name')
    food_qty = request.POST.getlist('food_qty')
    food_dict = {}
##    print(food_name)
##    print(food_qty)
    for i in range(len(food_name)):
        if food_qty[i] != '':
            food_dict[food_name[i]] = food_qty[i]

##    print(food_dict)
    for food,qty in food_dict.items():
##        print(food)
        food_item = Food.objects.get(name=food)
        item = Item(
            user = User.objects.get(username=request.user),
            food = food_item,
            qty = qty,
            price = str(int(food_item.price)*int(qty)))
        item.save()

    return redirect('order')

def order(request):
    global total_price
    user = User.objects.get(username=request.user)
    items = Item.objects.filter(user__username__icontains=user)
    print(items)
    total_price = 0
    for item in items:
        ordered_item = Food.objects.get(name=item.food)
        amount = int(ordered_item.price)*int(item.qty)
        total_price += amount
##    print(total_price)
    if request.method == 'POST':
        card_id = request.POST.get('card_id')
        expiry_date = request.POST.get('expiry_date')
        member = request.POST.get('member')
        payment_method = request.POST.get('payment_method')
##        print(payment_method)
        if member:
            order = Order(
                user = User.objects.get(username=request.user),
                member = True,
                card_id = card_id,
                expiry_date = expiry_date,
                payment_method = payment_method,
                total_amount = int(total_price)*0.8,
                discount = 0.2)
            order.save()
            return redirect('index')
        else:
            order = Order(
                user = User.objects.get(username=request.user),
                member = False,
                card_id = card_id,
                expiry_date = expiry_date,
                payment_method = payment_method,
                total_amount = total_price,
                discount = 0)
            order.save()
            return redirect('index')
    context = {'items':items,'total_price':float(total_price)}
    return render(request,'order.html',context)



    
    
    



    
