from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('food/pizza/',views.pizza_list,name='pizza_list'),
    path('food/pasta/',views.pasta_list,name='pasta_list'),
    path('shop/',views.shop,name='shop'),
    path('add_to_cart/',views.add_to_cart,name='add_to_cart'),
    path('order/',views.order,name='order'),
##    path('order_pay/',views.order_pay,name='order_pay'),
]
