from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Menu(models.Model):
    type_of_food = models.CharField(max_length=100)

    def __str__(self):
        return self.type_of_food

class Food(models.Model):
    menu = models.ForeignKey(Menu,on_delete=models.CASCADE)
    code = models.IntegerField()
    name = models.CharField(max_length=100)
    size = models.CharField(max_length=200,null=True,blank=True)
    ingredients = models.CharField(max_length=300,null=True,blank=True)
    image = models.ImageField(upload_to='images')
    price = models.FloatField()
    

    def __str__(self):
        return self.name


class SetMeal(models.Model):
    code = models.IntegerField()
    name = models.CharField(max_length=200)
    food = models.ManyToManyField(Food)
    image = models.ImageField(upload_to='images')
    price = models.FloatField()
   
    
    def __str__(self):
        return self.name

class Item(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    food = models.ForeignKey(Food,on_delete=models.CASCADE,null=True,blank=True)
    qty = models.IntegerField(null=True,blank=True)
    price = models.FloatField(null=True,blank=True)

    def __str__(self):
        return str(self.food)+' x '+str(self.qty)


class ItemMeal(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    meal = models.ForeignKey(SetMeal,on_delete=models.CASCADE,null=True,blank=True)
    qty = models.IntegerField(null=True,blank=True)
    price = models.FloatField(null=True,blank=True)

    def __str__(self):
        return str(self.meal)+' x '+str(self.qty)

    
    
class Order(models.Model):
    PAYMENT_OPTIONS = [
        ('Visa','Visa'),
        ('Debit Card','Debit Card'),
        ('Master Card','Master Card'),
    ]
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    member = models.BooleanField()
    card_id = models.IntegerField()
    expiry_date = models.DateField()
    total_amount = models.FloatField()
    discount = models.FloatField()
    payment_method = models.CharField(max_length=100,choices=PAYMENT_OPTIONS)

    def __str__(self):
        return str(self.user)+'\'s Payment'


